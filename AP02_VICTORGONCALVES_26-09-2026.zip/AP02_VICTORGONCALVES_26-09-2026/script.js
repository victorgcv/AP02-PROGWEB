/*
 Aluno: Victor Gonçalves
 Prog. Web - Uniavan
 */

const formulario = document.querySelector("#formulario-gasto");
const campoDescricao = document.querySelector("#descricao");
const campoValor = document.querySelector("#valor");
const campoCategoria = document.querySelector("#categoria");
const mensagemErro = document.querySelector("#mensagem-erro");

const listaGastos = document.querySelector("#lista-gastos");
const listaVazia = document.querySelector("#lista-vazia");
const filtroCategoria = document.querySelector("#filtro-categoria");

const totalElemento = document.querySelector("#total");
const contadorElemento = document.querySelector("#contador");

const botaoTema = document.querySelector("#botao-tema");

// FUNÇÕES DE FORMATAÇÃO

function formatarValor(valor) {
    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function classificarTotal(total) {
    if (total <= 500) {
        return "total-verde";
    }

    if (total <= 1000) {
        return "total-amarelo";
    }

    return "total-vermelho";
}


// FUNCOES DE VALIDACAO


function limparErros() {
    campoDescricao.parentElement.classList.remove("erro");
    campoValor.parentElement.classList.remove("erro");
    campoCategoria.parentElement.classList.remove("erro");
    mensagemErro.textContent = "";
}

function mostrarErro(mensagem, campo) {
    mensagemErro.textContent = mensagem;
    campo.parentElement.classList.add("erro");
    campo.focus();
}


// FUNÇÕES DE CONTROLE DA LISTA

function atualizarContador() {
    const quantidade = listaGastos.children.length;

    if (quantidade === 1) {
        contadorElemento.textContent = "1 gasto registrado";
    } else {
        contadorElemento.textContent = `${quantidade} gastos registrados`;
    }
}

function atualizarListaVazia() {
    const quantidade = listaGastos.children.length;

    if (quantidade === 0) {
        listaVazia.classList.remove("oculto");
    } else {
        listaVazia.classList.add("oculto");
    }
}

function atualizarFiltroDoItem(item) {
    const categoriaItem = item.getAttribute("data-categoria");
    const filtroAtual = filtroCategoria.value;

    if (filtroAtual === "Todas" || categoriaItem === filtroAtual) {
        item.classList.remove("oculto");
    } else {
        item.classList.add("oculto");
    }
}

function aplicarFiltro() {
    const itens = listaGastos.children;

    for (let i = 0; i < itens.length; i++) {
        atualizarFiltroDoItem(itens[i]);
    }
}

function recalcularTotal() {
    let total = 0;
    const itens = listaGastos.children;

    for (let i = 0; i < itens.length; i++) {
        const valor = Number(itens[i].getAttribute("data-valor"));
        total += valor;
    }

    totalElemento.textContent = formatarValor(total);

    totalElemento.classList.remove(
        "total-verde",
        "total-amarelo",
        "total-vermelho"
    );

    totalElemento.classList.add(classificarTotal(total));
}

function salvarGastos() {
    const gastos = [];
    const itens = listaGastos.children;

    for (let i = 0; i < itens.length; i++) {
        gastos.push({
            descricao: itens[i].getAttribute("data-descricao"),
            valor: Number(itens[i].getAttribute("data-valor")),
            categoria: itens[i].getAttribute("data-categoria")
        });
    }

    localStorage.setItem("controleGastos", JSON.stringify(gastos));
}

function carregarGastos() {
    const dadosSalvos = localStorage.getItem("controleGastos");

    if (dadosSalvos === null) {
        return;
    }

    const gastos = JSON.parse(dadosSalvos);

    for (let i = 0; i < gastos.length; i++) {
        criarItemGasto(
            gastos[i].descricao,
            gastos[i].valor,
            gastos[i].categoria
        );
    }
}

function criarItemGasto(descricao, valor, categoria) {
    const item = document.createElement("li");
    item.classList.add("item-gasto");

    item.setAttribute("data-valor", valor);
    item.setAttribute("data-categoria", categoria);
    item.setAttribute("data-descricao", descricao);

    const informacoes = document.createElement("div");
    informacoes.classList.add("informacoes-gasto");

    const descricaoElemento = document.createElement("span");
    descricaoElemento.classList.add("descricao-gasto");
    descricaoElemento.textContent = descricao;

    const categoriaElemento = document.createElement("span");
    categoriaElemento.classList.add("categoria-gasto");
    categoriaElemento.textContent = categoria;

    const valorElemento = document.createElement("span");
    valorElemento.classList.add("valor-gasto");
    valorElemento.textContent = formatarValor(valor);

    const botaoRemover = document.createElement("button");
    botaoRemover.type = "button";
    botaoRemover.classList.add("botao-remover");
    botaoRemover.textContent = "Remover";
    botaoRemover.setAttribute("aria-label", `Remover gasto ${descricao}`);

    informacoes.appendChild(descricaoElemento);
    informacoes.appendChild(categoriaElemento);

    item.appendChild(informacoes);
    item.appendChild(valorElemento);
    item.appendChild(botaoRemover);

    listaGastos.appendChild(item);

    atualizarFiltroDoItem(item);
    atualizarContador();
    atualizarListaVazia();
    recalcularTotal();
}

formulario.addEventListener("submit", function (event) {
    event.preventDefault();

    limparErros();

    const descricao = campoDescricao.value.trim();
    const valorDigitado = campoValor.value;
    const valor = Number(valorDigitado);
    const categoria = campoCategoria.value;

    if (descricao === "") {
        mostrarErro("Informe uma descrição para o gasto.", campoDescricao);
        return;
    }

    if (valorDigitado === "") {
        mostrarErro("Informe o valor do gasto.", campoValor);
        return;
    }

    if (Number.isNaN(valor) || valor <= 0) {
        mostrarErro("O valor deve ser maior que zero.", campoValor);
        return;
    }

    if (categoria === "") {
        mostrarErro("Selecione uma categoria.", campoCategoria);
        return;
    }

    criarItemGasto(descricao, valor, categoria);

    formulario.reset();
    mensagemErro.textContent = "";

    salvarGastos();
});

listaGastos.addEventListener("click", function (event) {
    if (event.target.classList.contains("botao-remover")) {
        const item = event.target.parentElement;

        item.remove();

        atualizarContador();
        atualizarListaVazia();
        recalcularTotal();
        salvarGastos();
    }
});

filtroCategoria.addEventListener("change", function () {
    aplicarFiltro();
});

// MODO ESCURO

botaoTema.addEventListener("click", function () {
    document.body.classList.toggle("modo-escuro");

    const modoEscuroAtivo = document.body.classList.contains("modo-escuro");

    if (modoEscuroAtivo) {
        botaoTema.textContent = "Modo claro";
        botaoTema.setAttribute("aria-label", "Ativar modo claro");
    } else {
        botaoTema.textContent = "Modo escuro";
        botaoTema.setAttribute("aria-label", "Ativar modo escuro");
    }
});

// INICIALIZAÇÃO

carregarGastos();
atualizarContador();
atualizarListaVazia();
recalcularTotal();
aplicarFiltro();